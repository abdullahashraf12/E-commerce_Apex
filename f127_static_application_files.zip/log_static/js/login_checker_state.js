var p=document.getElementById("id2")
    if(p.innerText=="t"){
        alert("you have been registered successfully")
    }else if(p.innerText=="a"){
        alert("Account is Not Registered")
    }else if(p.innerText=="wp"){
        alert("Password is Not Correct")
    
    }
