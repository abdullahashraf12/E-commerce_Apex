function adjustPopover_2(popover, iframe, res) {
    iframe.style.width = "500px"; // Adjust the width as needed
    iframe.style.height = "500px"; // Adjust the height as needed
    iframe.contentWindow.document.open();
    iframe.contentWindow.document.write(res);
    iframe.contentWindow.document.close();
}

const data_to_cart = {
    url_html: '',
    set set_url_html(url) {
        this.url_html = url;
    },
    get get_url_html() {
        return this.url_html;
    }
};

$(document).ready(function () {
   
   
 
    // Set the default whitelist for tooltips
    var myDefaultWhiteList = $.fn.tooltip.Constructor.Default.whiteList;
    myDefaultWhiteList.iframe = ['style', 'src', 'id', 'onload', 'contentWindow', 'class', 'width', 'height'];

// $('.pop-bottom').popover({
//     title: 'My Checkout',
//     html: true,
//     placement: 'bottom',
//     container: 'body',
//     content: function () {
//         return "<iframe id='my_iframe' style='width:500px;height:500px;'  class='popover' onload='adjustPopover_2(&quot;.pop-bottom&quot; , this , data_to_cart.get_url_html )'></iframe>";    
//     }
// });







$(".pop-bottom").popover({
    html: true,
    placement: 'bottom',
    container: 'body',
    content: function () {
           data_to_cart.set_url_html = `
    <html>
    <head>
    <title></title>
    </head>
    <body>
    <script>
    window.close();
    </script>
    <h1>Hello</h1>
    </body>
    </html>`;
        return "<iframe id='my_iframe' style='width:500px;height:500px;' class='popover' onload='adjustPopover_2(&quot;.pop-bottom&quot;, this, data_to_cart.get_url_html)'></iframe>";    
    }
});

// // Trigger popover on mouseover
$(".pop-bottom").on("mouseenter",function () {
    $(this).popover('show');
    //  $('#my_iframe').show();


});
$(document).on('mouseleave','#my_iframe',function(){
  $('.pop-bottom').popover('hide');
});

//  $("#my_iframe").on('mouseleave',function(){
//         $('#my_iframe').popover('hide');
//     });





// $(document).on('mouseleave','.popover-content',function(){
//     $(this).popover('hide');
// });




// $('.pop-bottom').popover({
//     title: 'My Checkout',
//     html: true,
//     placement: 'bottom',
//     container: 'body',
//     content: function () {
//         return "<iframe id='my_iframe' style='width:500px;height:500px;' class='popover my_iframe' onload='adjustPopover_2(&quot;.pop-bottom&quot;, this, data_to_cart.get_url_html)'></iframe>";    
//     }
// });

// // Trigger popover on mouseover
// $(".pop-bottom").on("mouseenter", function () {
//     $(this).popover('show');
// });

// $("#my_iframe").on("mouseleave", function () {
//     $('.pop-bottom').popover('dispose');
//     $(this).hide();
//     alert("iframe closed");
// });

// $(".popover.my_iframe").on("mouseleave", function () {
//     // $(this).popover('hide');
//     alert("mouse left iframe");
// });







    // Set the HTML content for the iframe

    // // Initialize the popover
    // $('.pop-bottom').popover({
    //     // trigger: 'hover',
    //     title: 'My Checkout',
    //     html: true,
    //     placement: 'bottom',
    //     container: 'body',
    //     content: function () {
    // return "<iframe id='my_iframe' style='width:500px;height:500px;'  class='popover' onload='adjustPopover_2(&quot;.pop-bottom&quot; , this , data_to_cart.get_url_html )'></iframe>";    
    //     }
    // });




});