    // $("#Review").load(location.href + " #Review");

function refreshReview(){
    // $("#Review").load(location.href + " #Review");
try{

    // $("#Review").load(location.href + " #Review");

    $(".my_star_rating").each(function(index, element) {
        // Get the value of #RATING# from the style attribute
        var styleAttribute = $(element).find(".star_rating___").attr("style");

        // Extract the numerical value from the style attribute
        var ratingValue = parseInt(styleAttribute.match(/\d+/));

        // Clear the existing content in the current .my_star_rating div
        $(element).empty();

        // Append gold stars based on the ratingValue
        for (var i = 0; i < ratingValue; i++) {
            $(element).append('<div class="gold" style="float: left;"><label><input readonly type="radio" name="rating" style="visibility:hidden"></label></div>');
        }
    // Reload the content of the "Review" div from the server


    })
    }catch(error){

    }
    //  $("#Review").load(location.href + " #Review");
}
setInterval(refreshReview, 500);
    

