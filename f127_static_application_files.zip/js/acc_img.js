$(window).on('load',function() {
    try{
    
    var account = $("#account_id").html();

    if(account==null || account=='nobody' ||account == 'ADMIN'){

    }else{
      
        var html_text='<img src="http://localhost:8080/ords/myschema/get_image/get_img/'+ account +'"style="width:45px; height:45px; border-radius: 50%;"'+'>'
           $('#account_image').html(html_text);
        
}
    }
catch {
    
}
}); 