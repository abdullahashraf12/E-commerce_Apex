$(document).ready(function() { 
    var number_of_stars=$(".my_div_star_review");
$(".my_div_star_review").each(function() {
if($(this).attr("number_of_stars")==0){
    $(this).html('<div class="silver" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');
}else if(number_of_stars.attr("number_of_stars")==1){
    $(this).html('<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');

}
else if($(this).attr("number_of_stars")==2){
    $(this).html('<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');

}
else if($(this).attr("number_of_stars")==3){
    $(this).html('<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');

}
else if($(this).attr("number_of_stars")==4){
    $(this).html(
        '<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div');

}
else if($(this).attr("number_of_stars")==5){
    $(this).html('<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');

}
else if($(this).attr("number_of_stars")==6){
    $(this).html('<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');

}
else {
    $(this).html('<div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div><div class="gold" style="float: left;"><label><input readonly class="pop-bottom" data-toggle="popover" title="Popover Header" data-html="true" type="radio" name="rating" style="visibility:hidden"></label></div>');
}

});
});

