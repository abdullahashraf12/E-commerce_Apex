function my_data(){
try{
    var url = window.location.href;

// Create a URLSearchParams object with the URL's search parameters
const params = new URLSearchParams(url);
// const categName = Number(Array.from(params.entries()[0][1]));
categ_name_number=Number(Array.from(params)[0][1]);

const containsNumber = /\d/.test(categ_name_number);

if (containsNumber) {
    console.log("The string contains a number.");
    apex.server.process(
    "My_Proc",
    { x01: apex.item("L_CATEG_CHECK").setValue(null)},
    {
      success: function(data) {
          alert("i am here 12 => null");
        // console.log("success categ_name is null "+categ_name_number.toString());

      },
      dataType: "text"
    }
  );
} else {
    console.log("The string does not contain a number.");
    apex.server.process(
    "My_Proc",
    { x01: apex.item("L_CATEG_CHECK").setValue(Array.from(params)[0][1].toString())},
    {
      success: function(data) {
      alert("i am here 2 => "+Array.from(params)[0][1].toString());

        // console.log("success categ_name is "+Array.from(params)[0][1]);
      },
      dataType: "text"
    }
  );
}

}catch(err){
    console.log(err);
}
}
my_data();
// var interval = setInterval(my_data(),200);
// });
// });




// });
// function my_data(){
// try{
//     var url = window.location.href;

// // Create a URLSearchParams object with the URL's search parameters
// const params = new URLSearchParams(url);
// // const categName = Number(Array.from(params.entries()[0][1]));
// categ_name_number=Number(Array.from(params)[0][1]);

// const containsNumber = /\d/.test(categ_name_number);

// if (containsNumber) {
//     console.log("The string contains a number.");
//     apex.server.process(
//     "My_Proc",
//     { x09: null},
//     {
//       success: function(data) {
//           alert("i am here");
//         // console.log("success categ_name is null "+categ_name_number.toString());

//       },
//       dataType: "text"
//     }
//   );
// } else {
//     console.log("The string does not contain a number.");
//     apex.server.process(
//     "My_Proc",
//     { x09: Array.from(params)[0][1]},
//     {
//       success: function(data) {
//         console.log("success categ_name is "+Array.from(params)[0][1]);
//       },
//       dataType: "text"
//     }
//   );
// }

// }catch(err){
//     console.log(err);
// }
// }
// my_data();
// var setinterval = setInterval(my_data,200)
// }else{
    
//  var url = window.location.href;

// // Create a URLSearchParams object with the URL's search parameters
// const params = new URLSearchParams(url);
//     const categName = Array.from(params.entries())[0][1];

//     apex.server.process(
//     "My_Proc",
//     { x01: categName.toString() },
//     {
//       success: function(data) {
//         // Handle success if needed
//       },
//       dataType: "text"
//     }
//   );
//     console.log('categ_name has value '+categName.toString());
//   console.log("here 2");

//     var url = window.location.href;

// // Create a URLSearchParams object with the URL's search parameters
// const params = new URLSearchParams(url);
//     const categName = Array.from(params.entries())[0][1];

//     apex.server.process(
//     "My_Proc",
//     { x01: categName.toString() },
//     {
//       success: function(data) {
//         // Handle success if needed
//       },
//       dataType: "text"
//     }
//   );
//     console.log('categ_name has value '+categName.toString());
//   console.log("here 2");