let exampleObject = {
    _data: '', // Private property
  
    // Getter method
    get data() {
    //   console.log('Getting data');
      return this._data;
    },
  
    // Setter method
    set data(newData) {
    //   console.log('Setting data');
      this._data = newData;
    }
  };
  
  function storeData() {
    // Generate or fetch your new string data
    
    exampleObject.data = $(".carousel-item.active.category").attr("id");
    
  apex.server.process(
    "CATEG_NAME",
    { x01: exampleObject._data},
  {
      success: function(data) {
        // console.log("Value sent to the server successfully");
        // console.log(data);
      },
      dataType: "text"
  }
  );

  
  $("#linky").attr("href",$("#URL_DATA").val());
// $("#My_Button").trigger("click");
    $("#My_Button").trigger("click");
      
  }
  const intervalId = setInterval(storeData, 200);
