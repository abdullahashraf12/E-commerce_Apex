$(document).ready(function () {


    function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Example usage
async function example(ms) {
  console.log("Start");
  await sleep(ms); // Sleep for 2 seconds
  console.log("End");
}



let exampleObject = {
    _data: '', // Private property
  
    // Getter method
    get data() {
    //   console.log('Getting data');
      return this._data;
    },
  
    // Setter method
    set data(newData) {
    //   console.log('Setting data');
      this._data = newData;
    }
  };
  function storeData() {
    // Generate or fetch your new string data
    
    exampleObject.data = $(".carousel-item.active.category").attr("id");
  apex.server.process(
    "CATEG_NAME",
    { x01: exampleObject._data},
  {
      success: function(data) {
        //   alert("class changed")
        // console.log("Value sent to the server successfully");
        // console.log(data);
      },
      dataType: "text"
  
  }


  );

  $("#linky").attr("href",$("#URL_DATA").val());
// $("#My_Button").trigger("click");
    $("#My_Button").trigger("click");
      
  }




storeData();
setInterval(function() {
  storeData()}, 300);


  function store_carousel_Data(e_id) {
    // Generate or fetch your new string data
    // alert(e.relatedTarget.id);

  apex.server.process(
    "CATEG_NAME",
    { x01: e_id},
  {
      success: function(data) {
        //   alert("class changed")
        // console.log("Value sent to the server successfully");
        // console.log(data);
      },
      dataType: "text"
  }
  );
//    $("#linky").attr("href",null)
  $("#linky").attr("href",$("#URL_DATA").val());
// $("#My_Button").trigger("click");
    $("#My_Button").trigger("click");
    // alert($("#linky").attr("href"));
  }


$("#carouselExampleIndicators").on('slide.bs.carousel', function(e) {
setInterval(function() {
   var ele_id= $(".carousel-item.active.category").attr("id");
  store_carousel_Data(ele_id, e);
}, 500);
});

});


