// Replace 'your_rest_endpoint_url' with the actual RESTful Web Service endpoint URL in your Oracle APEX application
const apiUrl = 'http://localhost:8080/ords/myschema/get_Category_image/get_data';

// Make a GET request using the fetch API
fetch(apiUrl, {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
    // Include any additional headers if required (e.g., authorization)
  },
})
  .then(response => {
    // Check if the response is successful (status code 200-299)
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    // Parse the JSON response
    return response.json();
  })
  .then(data => {
    // Handle the retrieved data
    console.log(data.category_data[0].CATEGORY_NAME);
    // $("#my_img_glob").html('<div class="carousel-item active category"><img class="d-block w-100" src="http://localhost:8080/ords/myschema/get_Category_image/${element}" alt="First slide"></div>');
    for (let index = 0; index < data.total_rows; index++) {
        const element = data.category_data[index].CATEGORY_NAME;
        const element_brief_desc = data.category_data[index].DEPARTMENT_BRIEF_DESC;

        console.log(element);
        if(index==0){
            $("#my_img_glob").append('<div class="carousel-item active category" id="'+element+'"><img class="d-block w-100" src="http://localhost:8080/ords/myschema/get_Category_image/'+element+'" alt="First slide"><div class="txt_container"><p class="text_text">'+element_brief_desc+'</p></div></div>');

        }else{
            $("#my_img_glob").append('<div class="carousel-item category" id="'+element+'"><img class="d-block w-100" src="http://localhost:8080/ords/myschema/get_Category_image/'+element+'" alt="Third slide"><div class="txt_container"><p class="text_text">'+element_brief_desc+'</p></div></div>')
        }
    }
    // Perform further processing as needed
  })
  .catch(error => {
    // Handle errors
    console.error('Error:', error);
  });





// DECLARE
//    json_data CLOB; -- Adjust the size as needed
//    cnt NUMBER;
// BEGIN
//    APEX_JSON.INITIALIZE_CLOB_OUTPUT;

//    APEX_JSON.OPEN_OBJECT; -- Open the main JSON object

//    APEX_JSON.OPEN_ARRAY('category_data'); -- Open the array within the main JSON object

//    FOR rec IN (SELECT CATEGORY_NAME, IMAGE_RANDOM FROM GLOBAL_CATEGORY) LOOP
//       APEX_JSON.OPEN_OBJECT; -- Open an object within the array
//       APEX_JSON.WRITE('CATEGORY_NAME', rec.CATEGORY_NAME);
//     --   APEX_JSON.WRITE_RAW('IMAGE_RANDOM', '"' || UTL_RAW.CAST_TO_VARCHAR2(rec.IMAGE_RANDOM) || '"');
//       APEX_JSON.CLOSE_OBJECT; -- Close the object within the array
//    END LOOP;

//    APEX_JSON.CLOSE_ARRAY; -- Close the array

//    -- Add the total number of rows to the main JSON object
//    SELECT COUNT(*) INTO cnt FROM GLOBAL_CATEGORY;
//    APEX_JSON.WRITE('total_rows', cnt);

//    APEX_JSON.CLOSE_OBJECT; -- Close the main JSON object

//    json_data := APEX_JSON.GET_CLOB_OUTPUT;

//    -- Set the MIME header for the JSON response
//    OWA_UTIL.MIME_HEADER('application/json', FALSE);
//    HTP.P('Content-length: ' || DBMS_LOB.GETLENGTH(json_data));
//    OWA_UTIL.HTTP_HEADER_CLOSE;

//    -- Output the JSON data
//    HTP.P(json_data);
// END;
